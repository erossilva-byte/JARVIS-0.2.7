package com.jarvis.nova;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.getcapacitor.JSObject;
import com.getcapacitor.PermissionState;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.annotation.PermissionCallback;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Locale;
import java.util.regex.Pattern;

/**
 * 1) Serviço em primeiro plano que mantém o Jarvis vivo com o app aberto.
 * 2) Palavra de ativação "Jarvis" usando o reconhecimento de voz do Android
 *    (no aparelho, sem gastar a API da Groq). Ao ouvir o nome, dispara o evento "wake".
 */
@CapacitorPlugin(
    name = "JarvisBackground",
    permissions = { @Permission(strings = { Manifest.permission.RECORD_AUDIO }, alias = "mic") }
)
public class JarvisBackgroundPlugin extends Plugin {

    private static final Pattern WAKE = Pattern.compile(
        "\\b(jarvis|jarvi|jarves|jervis|gervis|garvis|charvis|jarbis|jarvez|jarvs)\\b");

    // Durante a fala do Jarvis (modo "parar"): só dispara com "Jarvis" + uma palavra de parada.
    private static final Pattern PARAR = Pattern.compile(
        "\\b(para|pare|parar|chega|silencio|cala|calma|cancela|cancelar)\\b");

    private final Handler main = new Handler(Looper.getMainLooper());
    private boolean modoParar = false;
    private SpeechRecognizer rec;
    private boolean querWake = false;
    private boolean somenteLocalWake = false;
    private boolean acordou = false;
    private String ultimoParcial = "";
    private int geracao = 0;
    private SpeechRecognizer transcricaoRec;
    private PluginCall transcricaoCall;
    private Runnable transcricaoTimeout;
    private String textoParcialTranscricao = "";

    /* ---------- Serviço em segundo plano ---------- */

    @PluginMethod
    public void start(PluginCall call) {
        // No Android 14+ o serviço de microfone só pode iniciar com a permissão já concedida.
        if (getPermissionState("mic") != PermissionState.GRANTED) {
            requestPermissionForAlias("mic", call, "aposPermissaoMic");
            return;
        }
        iniciar(call);
    }

    @PermissionCallback
    private void aposPermissaoMic(PluginCall call) {
        if (getPermissionState("mic") == PermissionState.GRANTED) {
            iniciar(call);
        } else {
            call.reject("Microfone negado");
        }
    }

    private void iniciar(PluginCall call) {
        try {
            if (Build.VERSION.SDK_INT >= 33
                && ContextCompat.checkSelfPermission(getContext(), "android.permission.POST_NOTIFICATIONS")
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(
                    getActivity(), new String[] { "android.permission.POST_NOTIFICATIONS" }, 7301);
            }
            ContextCompat.startForegroundService(getContext(), new Intent(getContext(), JarvisService.class));
            call.resolve();
        } catch (Exception e) {
            call.reject("Não consegui iniciar o serviço: " + e.getMessage());
        }
    }

    @PluginMethod
    public void stop(PluginCall call) {
        getContext().stopService(new Intent(getContext(), JarvisService.class));
        call.resolve();
    }

    /* ---------- Palavra de ativação ---------- */

    @PluginMethod
    public void startWake(PluginCall call) {
        if (getPermissionState("mic") != PermissionState.GRANTED) {
            requestPermissionForAlias("mic", call, "aposPermissaoWake");
            return;
        }
        iniciarWake(call);
    }

    @PermissionCallback
    private void aposPermissaoWake(PluginCall call) {
        if (getPermissionState("mic") == PermissionState.GRANTED) {
            iniciarWake(call);
        } else {
            call.reject("Microfone negado");
        }
    }

    private void iniciarWake(PluginCall call) {
        if (!SpeechRecognizer.isRecognitionAvailable(getContext())) {
            call.reject("Reconhecimento de voz indisponível neste aparelho");
            return;
        }
        modoParar = Boolean.TRUE.equals(call.getBoolean("parar", false));
        somenteLocalWake = Boolean.TRUE.equals(call.getBoolean("somenteLocal", false));
        if (somenteLocalWake && (Build.VERSION.SDK_INT < 31 || !SpeechRecognizer.isOnDeviceRecognitionAvailable(getContext()))) {
            call.reject("Modo offline: este aparelho não oferece reconhecimento de voz local disponível. Desative o modo offline ou digite o comando.");
            return;
        }
        querWake = true;
        main.post(this::ouvir);
        call.resolve();
    }

    @PluginMethod
    public void stopWake(final PluginCall call) {
        querWake = false;
        main.post(() -> {
            destruir();
            call.resolve();
        });
    }

    /* ---------- Transcrição alternativa do Android ---------- */

    @PluginMethod
    public void transcreverNativo(PluginCall call) {
        if (getPermissionState("mic") != PermissionState.GRANTED) {
            requestPermissionForAlias("mic", call, "aposPermissaoTranscricao");
            return;
        }
        main.post(() -> iniciarTranscricaoNativa(call));
    }

    @PermissionCallback
    private void aposPermissaoTranscricao(PluginCall call) {
        if (getPermissionState("mic") == PermissionState.GRANTED) {
            main.post(() -> iniciarTranscricaoNativa(call));
        } else {
            call.reject("Permissão do microfone negada.");
        }
    }

    @PluginMethod
    public void cancelarTranscricaoNativa(PluginCall call) {
        main.post(() -> {
            PluginCall pendente = transcricaoCall;
            encerrarTranscricaoNativa();
            if (pendente != null) pendente.reject("Transcrição cancelada pelo usuário.");
            call.resolve();
        });
    }

    private void iniciarTranscricaoNativa(PluginCall call) {
        if (!SpeechRecognizer.isRecognitionAvailable(getContext())) {
            call.reject("O Android não oferece um serviço de reconhecimento de voz neste aparelho.");
            return;
        }
        encerrarTranscricaoNativa();
        // Só pode haver uma sessão de reconhecimento por vez no plugin.
        querWake = false;
        destruir();
        transcricaoCall = call;
        textoParcialTranscricao = "";
        boolean somenteLocal = Boolean.TRUE.equals(call.getBoolean("somenteLocal", false));
        if (somenteLocal && (Build.VERSION.SDK_INT < 31 || !SpeechRecognizer.isOnDeviceRecognitionAvailable(getContext()))) {
            transcricaoCall = null;
            call.reject("Modo offline: reconhecimento de voz local indisponível neste aparelho.");
            return;
        }
        try {
            if (Build.VERSION.SDK_INT >= 31 && SpeechRecognizer.isOnDeviceRecognitionAvailable(getContext())) {
                transcricaoRec = SpeechRecognizer.createOnDeviceSpeechRecognizer(getContext());
            } else {
                transcricaoRec = SpeechRecognizer.createSpeechRecognizer(getContext());
            }
        } catch (Exception e) {
            encerrarTranscricaoNativa();
            call.reject("Não consegui iniciar o reconhecimento Android: " + e.getMessage());
            return;
        }
        transcricaoRec.setRecognitionListener(new RecognitionListener() {
            @Override public void onReadyForSpeech(Bundle params) { }
            @Override public void onBeginningOfSpeech() { }
            @Override public void onRmsChanged(float rmsdB) { }
            @Override public void onBufferReceived(byte[] buffer) { }
            @Override public void onEndOfSpeech() { }
            @Override public void onEvent(int eventType, Bundle params) { }

            @Override public void onPartialResults(Bundle results) {
                ArrayList<String> lista = results == null ? null : results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (lista != null && !lista.isEmpty()) textoParcialTranscricao = lista.get(0);
            }

            @Override public void onResults(Bundle results) {
                ArrayList<String> lista = results == null ? null : results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                String texto = (lista != null && !lista.isEmpty()) ? lista.get(0) : textoParcialTranscricao;
                PluginCall atual = transcricaoCall;
                encerrarTranscricaoNativa();
                if (atual == null) return;
                if (texto == null || texto.trim().isEmpty()) {
                    atual.reject("O Android não reconheceu uma frase. Tente novamente ou digite o comando.");
                    return;
                }
                JSObject ret = new JSObject();
                ret.put("texto", texto.trim());
                ret.put("mecanismo", Build.VERSION.SDK_INT >= 31 && SpeechRecognizer.isOnDeviceRecognitionAvailable(getContext()) ? "local" : "servico-android");
                atual.resolve(ret);
            }

            @Override public void onError(int error) {
                PluginCall atual = transcricaoCall;
                String parcial = textoParcialTranscricao;
                encerrarTranscricaoNativa();
                if (atual == null) return;
                if (parcial != null && !parcial.trim().isEmpty()) {
                    JSObject ret = new JSObject(); ret.put("texto", parcial.trim()); ret.put("mecanismo", "parcial-android"); atual.resolve(ret);
                } else {
                    String motivo;
                    switch (error) {
                        case SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS: motivo = "Permissão de microfone insuficiente."; break;
                        case SpeechRecognizer.ERROR_NETWORK:
                        case SpeechRecognizer.ERROR_NETWORK_TIMEOUT: motivo = "O serviço de reconhecimento Android precisa de rede."; break;
                        case SpeechRecognizer.ERROR_NO_MATCH:
                        case SpeechRecognizer.ERROR_SPEECH_TIMEOUT: motivo = "Nenhuma fala reconhecida pelo Android."; break;
                        case SpeechRecognizer.ERROR_RECOGNIZER_BUSY: motivo = "O reconhecedor Android está ocupado."; break;
                        default: motivo = "Falha no reconhecimento Android (código " + error + ").";
                    }
                    atual.reject(motivo);
                }
            }
        });

        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR");
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "pt-BR");
        intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
        intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3);
        intent.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true);
        intent.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, getContext().getPackageName());
        transcricaoTimeout = () -> {
            PluginCall atual = transcricaoCall;
            encerrarTranscricaoNativa();
            if (atual != null) atual.reject("Tempo esgotado no reconhecimento Android. Tente de novo ou digite o comando.");
        };
        main.postDelayed(transcricaoTimeout, 18000);
        try {
            transcricaoRec.startListening(intent);
        } catch (Exception e) {
            PluginCall atual = transcricaoCall;
            encerrarTranscricaoNativa();
            if (atual != null) atual.reject("Não consegui iniciar a escuta Android: " + e.getMessage());
        }
    }

    private void encerrarTranscricaoNativa() {
        if (transcricaoTimeout != null) main.removeCallbacks(transcricaoTimeout);
        transcricaoTimeout = null;
        transcricaoCall = null; // zera antes de cancelar para impedir callbacks duplicados
        SpeechRecognizer atual = transcricaoRec;
        transcricaoRec = null;
        if (atual != null) {
            try { atual.cancel(); atual.destroy(); } catch (Exception ignored) { }
        }
        textoParcialTranscricao = "";
    }

    private static String normalizar(String s) {
        return Normalizer.normalize(s == null ? "" : s, Normalizer.Form.NFD)
            .replaceAll("\\p{M}", "")
            .toLowerCase(Locale.ROOT);
    }

    private boolean gatilho(String s) {
        String n = normalizar(s);
        if (!WAKE.matcher(n).find()) return false;
        return !modoParar || PARAR.matcher(n).find();
    }

    private String melhor(Bundle b) {
        if (b == null) return "";
        ArrayList<String> l = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        if (l == null || l.isEmpty()) return "";
        for (String s : l) {
            if (gatilho(s)) return s;
        }
        return l.get(0);
    }

    private void destruir() {
        geracao++;
        if (rec != null) {
            try {
                rec.cancel();
                rec.destroy();
            } catch (Exception e) {
                // ignora
            }
            rec = null;
        }
    }

    private void reiniciar(long atrasoMs) {
        if (querWake) main.postDelayed(this::ouvir, atrasoMs);
    }

    private void disparar(String texto) {
        querWake = false;
        destruir();
        JSObject o = new JSObject();
        o.put("texto", texto == null ? "" : texto);
        notifyListeners("wake", o);
    }

    private void ouvir() {
        if (!querWake) return;
        destruir();
        acordou = false;
        ultimoParcial = "";
        final int gen = geracao;
        try {
            if (somenteLocalWake && Build.VERSION.SDK_INT >= 31 && SpeechRecognizer.isOnDeviceRecognitionAvailable(getContext())) {
                rec = SpeechRecognizer.createOnDeviceSpeechRecognizer(getContext());
            } else {
                rec = SpeechRecognizer.createSpeechRecognizer(getContext());
            }
        } catch (Exception e) {
            reiniciar(2000);
            return;
        }
        rec.setRecognitionListener(new RecognitionListener() {
            @Override public void onReadyForSpeech(Bundle p) { }
            @Override public void onBeginningOfSpeech() { }
            @Override public void onRmsChanged(float v) { }
            @Override public void onBufferReceived(byte[] b) { }
            @Override public void onEndOfSpeech() { }
            @Override public void onEvent(int t, Bundle p) { }

            @Override
            public void onPartialResults(Bundle b) {
                if (gen != geracao) return;
                String t = melhor(b);
                if (!t.isEmpty()) {
                    ultimoParcial = t;
                    // Marca que ouviu o nome, mas espera o fim da frase para pegar o comando junto.
                    if (gatilho(t)) acordou = true;
                }
            }

            @Override
            public void onResults(Bundle b) {
                if (gen != geracao) return;
                String t = melhor(b);
                if (t.isEmpty()) t = ultimoParcial;
                if (acordou || gatilho(t)) disparar(t);
                else reiniciar(150);
            }

            @Override
            public void onError(int erro) {
                if (gen != geracao) return;
                if (erro == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                    querWake = false;
                    JSObject o = new JSObject();
                    o.put("motivo", "sem permissão de microfone");
                    notifyListeners("wakeparou", o);
                    return;
                }
                if (acordou && !ultimoParcial.isEmpty()) {
                    disparar(ultimoParcial);
                    return;
                }
                if (erro == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) reiniciar(1000);
                else if (erro == SpeechRecognizer.ERROR_NO_MATCH || erro == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) reiniciar(150);
                else reiniciar(700);
            }
        });
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR");
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3);
        i.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, getContext().getPackageName());
        try {
            rec.startListening(i);
        } catch (Exception e) {
            reiniciar(1500);
        }
    }

    @Override
    protected void handleOnDestroy() {
        querWake = false;
        main.post(() -> { destruir(); encerrarTranscricaoNativa(); });
        super.handleOnDestroy();
    }
}
