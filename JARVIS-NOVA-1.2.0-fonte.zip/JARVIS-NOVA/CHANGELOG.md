# Histórico de versões — J.A.R.V.I.S. Nova

## 1.1.0 — 2026-10-14 (código-fonte; APK depende de compilação/teste)

- Mantém Groq como prioridade e as opções de chave Gemini, Cerebras e Mistral existentes, com fallback já presente no projeto.
- Adiciona modo offline que bloqueia chamadas de IA e testes de rede; comandos locais continuam disponíveis.
- Usa reconhecimento de voz nativo em modo estritamente local quando o Android oferece esse recurso. Palavra de ativação offline exige reconhecimento on-device; se indisponível, a função não deve recorrer silenciosamente à rede.
- Adiciona comandos locais para pausar/retomar mídia, faixa seguinte/anterior, volume, status de bateria/conexão, sair para a tela inicial e reabrir aplicativos conhecidos.
- Adiciona composição de SMS com texto preparado; o usuário revisa e toca em enviar. Mensagens de WhatsApp continuam abrindo com texto preparado, sem envio silencioso.
- Adiciona leitura de até dez resumos de notificações recentes após autorização explícita do Android e tentativa de resposta rápida à última notificação que exponha RemoteInput.
- Adiciona anúncio opcional de chamadas apenas quando o Android classifica a notificação como chamada e o usuário ativa a opção.
- Adiciona abertura da agenda e criação de evento por meio do editor de calendário do Android, para revisão e salvamento pelo usuário.
- Mantém alarmes e lembretes persistentes, rotinas, memória configurável, diagnóstico e modo de conversa ampliada.
- Ações sensíveis continuam sujeitas ao modo seguro e à confirmação. O modo seguro pode bloquear ligações e mensagens até ser desligado em Ajustes; a confirmação permanece obrigatória.
- O encerramento forçado de outros apps não é oferecido: o comando de saída volta à tela inicial e o comando de retorno tenta reabrir o app conhecido.

### Limitações conhecidas a testar no aparelho

- A disponibilidade de reconhecimento local em português varia conforme versão do Android, serviço de voz e pacotes instalados.
- Leitura de notificações exige ativação manual do acesso especial. O conteúdo lido é apenas o que aparece na notificação, não o histórico completo de conversas.
- Resposta por voz só funciona se a notificação ativa fornecer ação de resposta rápida compatível.
- Anúncio de chamada depende de o aplicativo de telefone emitir notificação categorizada como chamada; fabricantes podem variar.
- Controles de mídia dependem do aplicativo de reprodução.
- O evento de calendário é aberto para revisão e precisa ser salvo pelo usuário.
- O Android pode impedir o reinício automático de serviço com microfone após reinicialização; alarmes são restaurados, mas o usuário pode precisar abrir o J.A.R.V.I.S. novamente para reativar escuta.
- Ainda não há validação física de chamadas, notificações, mídia, voz offline ou build Android nesta etapa.
