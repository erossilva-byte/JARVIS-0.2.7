// Lista de apps que o Jarvis pode abrir. Adicione os seus.
// win/mac/linux: protocolo (spotify:), URL ou nome de executável.
// android: esquema de URL do app (precisa estar instalado).
const APPS = {
  spotify:   { win: 'spotify:',  mac: 'spotify:',  linux: 'spotify:',  android: 'spotify:' },
  whatsapp:  { win: 'whatsapp:', mac: 'whatsapp:', linux: 'https://web.whatsapp.com', android: 'whatsapp://send' },
  youtube:   { win: 'https://www.youtube.com', mac: 'https://www.youtube.com', linux: 'https://www.youtube.com', android: 'vnd.youtube://' },
  navegador: { win: 'https://www.google.com', mac: 'https://www.google.com', linux: 'https://www.google.com', android: 'https://www.google.com' },
  calculadora: { win: 'calculator:', mac: '', linux: 'gnome-calculator', android: '' },
  bloco_de_notas: { win: 'notepad.exe', mac: '', linux: 'gedit', android: '' },
  explorador: { win: 'explorer.exe', mac: '', linux: 'nautilus', android: '' },
  maps:      { win: 'https://maps.google.com', mac: 'https://maps.google.com', linux: 'https://maps.google.com', android: 'geo:0,0' },
  instagram: { win: 'https://www.instagram.com', mac: 'https://www.instagram.com', linux: 'https://www.instagram.com', android: 'instagram://app' }
};
if (typeof module !== 'undefined' && module.exports) module.exports = APPS;
else window.APPS = APPS;
