"""Adiciona a dependência do detector local Porcupine ao app Android gerado pelo Capacitor."""
import re
import sys
from pathlib import Path

path = Path(sys.argv[1])
text = path.read_text(encoding="utf-8")
coordinate = "implementation 'ai.picovoice:porcupine-android:4.0.2'"
if coordinate in text:
    print(f"Dependência Porcupine já presente: {path}")
    raise SystemExit(0)
match = re.search(r"\bdependencies\s*\{", text)
if not match:
    raise SystemExit(f"Bloco dependencies {{ não encontrado em {path}")
start = match.end() - 1
level = 0
end = None
for i in range(start, len(text)):
    if text[i] == "{":
        level += 1
    elif text[i] == "}":
        level -= 1
        if level == 0:
            end = i
            break
if end is None:
    raise SystemExit(f"Bloco dependencies incompleto em {path}")
text = text[:end] + "    " + coordinate + "\n" + text[end:]
path.write_text(text, encoding="utf-8")
print(f"Dependência Porcupine adicionada: {path}")
