# J.A.R.V.I.S. Nova 1.2.0 — app independente

> **Nota sobre a palavra de ativação:** a opção “Priorizar música e vídeos” pausa a escuta experimental enquanto o Android informa que há mídia tocando, para reduzir a disputa pelo microfone/áudio. Durante a música, use o botão de microfone. Esta é uma proteção intermediária; o comportamento igual ao “Ok Google” exige integrar um detector local de wake word dedicado.

Esta pasta contém a fonte da Nova, criada a partir do ZIP 0.9.0 auditado. O pacote Android permanece `com.jarvis.nova`, diferente das versões legadas conhecidas (`com.jarvis.app` e `com.jarvis.assistente`), para poderem ser instaladas lado a lado. Nenhum arquivo do app antigo é sobrescrito.

## Novidades desta versão

- Alarmes, lembretes e timers futuros são guardados nativamente e restaurados após reiniciar o telefone, mudar a hora ou atualizar o app. Um alarme cuja hora já passou enquanto o aparelho estava desligado é removido em vez de disparar inesperadamente ao iniciar.
- O serviço em primeiro plano não é encerrado apenas por remover o aplicativo da tela de recentes. A notificação permanente apresenta controle para parar o serviço. Isto melhora a persistência do serviço, mas não garante escuta ininterrupta: restrições de microfone do Android, falta de suporte do reconhecedor e políticas de bateria do fabricante ainda podem interrompê-la.
- Parâmetros de alarmes recebem validação defensiva e prazo máximo de um ano.
- Versão Android: `1.2.0`, `versionCode 1200`.

- Interface premium refinada, estados de foco/escuta, barra de contexto e cartões de pesquisa com domínio, título, resumo, data quando identificável e aviso que distingue referências retornadas pelo navegador de links citados pelo modelo.
- Configurações em categorias: IA, Voz, Privacidade, Memória, Rotinas, Segurança e Diagnóstico.
- Contexto da conversa e memória pessoal controlados separadamente a cada sessão. O histórico recente pode ser retirado do prompt sem apagar a conversa; a memória editável só entra no prompt se os controles global e da conversa estiverem ligados.
- Painel de microfone com nível visual, estimativa de ruído, pico, sensibilidade e teste de permissões/recursos de áudio.
- Controle rápido para pausar/reativar a palavra de ativação no Android. O reconhecedor depende do serviço instalado/configurado no telefone, e o app não garante escuta permanente nem operação offline.
- Editor visual de rotinas para criar, editar, reordenar, remover e excluir sequências sem escrever JSON manualmente. Limites: 20 rotinas e 8 ações por rotina; ações críticas mantêm confirmação e modo seguro.
- Central de privacidade com transparência de dados locais e enviados a provedores, exclusão de histórico/memória/registros e exclusão separada de chaves.
- Diagnóstico de compatibilidade do áudio, estado de permissão quando disponível, conexão, chaves configuradas e teste de pesquisa. A presença de uma chave não comprova validade ou saldo.
- Versionamento explícito (`1.2.0`, `versionCode 1200`), changelog, teste estático do projeto e workflow de build que só publica artefato se o Gradle concluir.

## O que fica no aparelho e o que sai dele

Preferências, rotinas, memória pessoal e registros são guardados localmente. O histórico persistente é opcional. No Android, o app tenta guardar chaves no cofre nativo; no navegador, o armazenamento local não deve ser tratado como cofre criptográfico. Mensagens e contexto habilitado podem ser enviados ao provedor IA; consultas de pesquisa seguem à Groq; o áudio pode ser enviado à Groq para transcrição quando o caminho nativo falha; dados de clima são solicitados ao Open-Meteo. Desative o compartilhamento de nomes de contato, contexto recente ou memória se não quiser enviá-los ao modelo. Os controles do aplicativo não podem prometer as políticas de retenção dos provedores externos.

## Gerar o APK pelo GitHub Actions

1. Crie um **repositório novo** no GitHub (privado é uma boa escolha) e envie todos os arquivos desta pasta, incluindo `.github/workflows/build-apk.yml`.
2. No repositório novo, abra **Actions**. Se aparecer um aviso para habilitar workflows, habilite-os.
3. Selecione **Build e testes do J.A.R.V.I.S. Nova** e clique em **Run workflow**. Também inicia automaticamente ao enviar um commit à branch `main`.
4. Abra a execução e acompanhe os passos. Só se todos terminarem verdes o workflow disponibiliza o artefato **JARVIS-Nova-1.2.4-APK**.
5. Na parte inferior da execução bem-sucedida, baixe o artefato; dentro do ZIP estará `app-debug.apk` e o arquivo de checksum.
6. Instale `app-debug.apk` no Android. Se o sistema pedir autorização para instalar apps desconhecidos, permita para o navegador/gerenciador de arquivos utilizado.
7. Abra J.A.R.V.I.S. Nova > Configurações > IA e cole a chave Groq. Conceda microfone quando solicitado e execute o diagnóstico integrado.

**O workflow não guarda segredos de IA no repositório.** Configure chaves apenas dentro do app instalado; jamais as escreva em `app.js`, arquivos de configuração, commits ou issues públicas.

## Compilar localmente

Requer Node.js 20, JDK 17, Android SDK/Android Studio compatível e ferramentas de plataforma instaladas.

```bash
npm install --ignore-scripts --legacy-peer-deps
npm run test:all
mkdir -p www
cp index.html style.css app.js apps.js www/
npx cap add android
npx cap sync android
D=android/app/src/main/java/com/jarvis/nova
mkdir -p "$D"
cp MainActivity.java JarvisBackgroundPlugin.java JarvisService.java JarvisUtilPlugin.java JarvisAlarmReceiver.java JarvisAlarmScheduler.java JarvisBootReceiver.java "$D/"
python3 patch_manifest.py android/app/src/main/AndroidManifest.xml
python3 patch_android_version.py android/app/build.gradle VERSAO.json
python3 patch_visual.py android
cd android
./gradlew assembleDebug --no-daemon
```

O APK gerado fica em `android/app/build/outputs/apk/debug/app-debug.apk`. Se não houver Android SDK configurado, rode a compilação pelo GitHub Actions. A existência do workflow não significa que um APK foi compilado: confirme que o passo **Compilar APK debug** terminou em sucesso e que o artefato foi enviado.

## Desktop

```bash
npm install
npm run test:all
npm start
```

Para gerar instalador Windows, use `npm run dist` em ambiente com as dependências completas do Electron.

## Lista de tarefas (v1.2.0)

Abra o botão de lista no topo para adicionar, marcar, filtrar e remover tarefas. As tarefas e prazos são salvos localmente neste aparelho e ficam disponíveis offline. Comandos locais aceitos incluem `Jarvis, adicionar tarefa estudar eletrônica`, `Jarvis, listar tarefas` e `Jarvis, concluir tarefa estudar eletrônica`. Os prazos são informativos nesta versão: a lista não cria notificações automáticas em segundo plano.

## Voz e modo offline automáticos (v1.2.0)

Em Configurações > Voz, escolha uma voz instalada, ajuste o tom (mais grave/agudo) e a velocidade, e use os botões de predefinição ou Testar voz. O resultado depende do motor de voz do sistema.

Com a alternância automática habilitada, o app reage aos eventos `offline` e `online` do sistema e tenta bloquear novas chamadas quando a conexão é perdida. A detecção depende do estado de rede reportado pelo sistema; perda de acesso à internet mantendo Wi-Fi/Ethernet conectado pode não gerar evento. Para máxima garantia, ative o modo offline manualmente. No desktop, a transcrição online é bloqueada quando o modo offline está ativo.

## Uso de rotinas

Abra **Configurações > Rotinas**, preencha o nome, escolha uma ação, preencha os parâmetros indicados, adicione à lista e salve a rotina. As ações podem ser reordenadas com as setas. Depois, diga `Jarvis, executar rotina bom dia`, substituindo pelo nome que escolheu. Rotinas com ações indisponíveis na plataforma atual não podem executar essas ações. Operações sensíveis continuam sujeitas às verificações do app.

## Limitações e testes de aparelho

- Em Android 12 ou posterior, o sistema pode exigir autorização especial para alarmes exatos. O Jarvis abre a tela de permissão quando necessário; conceda o acesso e repita o comando. A restauração de alarmes foi implementada no código, mas deve ser testada num Android físico: agendar dois lembretes, reiniciar antes do vencimento, confirmar a notificação no horário e cancelar outro antes de reiniciar. Os sistemas podem aplicar restrições extras de bateria.

- A pesquisa web depende de conexão, chave Groq válida, modelo compatível e limites da conta. Quando um endereço veio apenas do texto do modelo, o cartão avisa que o link não foi verificado independentemente. Confira a página original antes de confiar em notícias, cotações ou informações críticas.
- Datas só aparecem quando extraídas em formato reconhecível da resposta ou dos metadados da fonte; uma data ausente não é inventada.
- Microfone, palavra de ativação, estado de tela bloqueada, execução em segundo plano e consumo de bateria precisam ser validados no aparelho Android que será usado.
- Histórico persistente é opcional; memória pessoal é manual. Não inclua senhas, documentos, números bancários ou outros dados sensíveis em prompts, contatos ou memória.

## Novidades da versão-fonte 1.2.0

### Modo offline

Ative em Ajustes → Voz e microfone → Modo offline, ou diga “Jarvis, ativar modo offline”. Enquanto estiver ativo, o fluxo de conversa não chama Groq, Gemini, Cerebras ou Mistral, a pesquisa/clima online é bloqueada e os testes de rede do diagnóstico são pulados. O chip de status passa a mostrar “Modo offline”.

Comandos locais que podem continuar disponíveis: hora/data, alarmes/lembretes/timers locais, rotinas que usam ações locais, abrir aplicativos conhecidos, sair para a tela inicial e reabrir apps conhecidos, controles de mídia/volume, consultar bateria/conexão, abrir agenda e preparar um evento no calendário, ler notificações previamente recebidas e preparar SMS/WhatsApp (o envio exige ação do usuário). Se uma solicitação exigir IA ou internet, o Jarvis explica que ela não pode ser executada offline.

**Voz offline:** no modo offline, o app solicita reconhecimento on-device do Android. Isso só funciona se o aparelho oferecer e tiver disponível um serviço de reconhecimento local compatível com português. Se não estiver disponível, a escuta por palavra-chave ou a transcrição pode falhar; o app não deve recorrer ao serviço online em modo offline. A fala de resposta usa o mecanismo TTS instalado no aparelho.

### Comunicação, notificações e apps

- Ligações: abre o discador para revisão; o usuário confirma/inicia a chamada no Android. O modo seguro pode bloquear ações críticas até ser desligado nos Ajustes; a confirmação continua obrigatória.
- SMS: abre o aplicativo de SMS com número e texto preenchidos; o usuário revisa e envia.
- WhatsApp: abre uma conversa com texto preparado; o usuário toca em enviar.
- Leitura: depois de habilitar manualmente o acesso especial às notificações nas configurações do Android, o app pode ler os últimos resumos de notificações recebidas. Não acessa automaticamente todo o histórico de mensagens.
- Resposta por voz: tenta responder à notificação ativa mais recente que disponibilize uma ação de resposta rápida. O Android/app pode não oferecer essa ação.
- Anúncio de chamadas: opção desativada por padrão; depende de acesso a notificações e de a notificação do telefone estar categorizada como chamada.
- Sair de apps: retorna à tela inicial; não força encerramento. “Retorne para [app]” tenta abrir um app conhecido e instalado.
- Mídia: envia eventos de controle padrão do Android; a compatibilidade depende do app de música/vídeo.
- Agenda: abre o calendário; criação abre o editor do evento para revisão e salvamento manual.

### Permissões e privacidade

O usuário deve conceder manualmente acesso às notificações para leitura/resposta. A função de leitura armazena até dez resumos recentes no armazenamento privado do app e os remove ao serem lidos. Não habilite o acesso se não quiser que o Jarvis veja o conteúdo das notificações. Chaves de API permanecem guardadas no cofre Android existente.

### Limites do Android

O Android não permite que um app comum force o encerramento de qualquer outro aplicativo. O serviço de voz também não pode ser garantido ativo após reinicialização, especialmente em versões recentes do Android com restrições a serviços de microfone; os alarmes persistentes são restaurados, mas pode ser necessário abrir o app para retomar a escuta.


### Desligar escuta e apagar dados

A Central de privacidade tem um botão combinado para desligar a escuta/serviço de segundo plano e apagar histórico, memória, registros e resumos de notificações. Ele preserva as chaves API, os contatos e as demais configurações; chaves podem ser apagadas separadamente em Ajustes → IA.


## Ativação experimental por voz — 1.2.3 (histórico)

A versão 1.2.3 usava `SpeechRecognizer` para procurar a palavra-chave e não tinha detector dedicado. Esse comportamento foi substituído pela integração Porcupine descrita na seção da versão 1.2.4 abaixo.

O serviço em primeiro plano com notificação só é solicitado quando a ativação está ligada e a preferência de segundo plano está habilitada. O `WakeLock` parcial permanente foi removido; isso evita manter a CPU acordada por até 12 horas sem necessidade, mas também significa que a continuidade da escuta com a tela apagada ainda precisa de validação em hardware real. Alarmes e lembretes agendados usam o agendador nativo do Android e não dependem desse serviço.


## Ativação local por palavra-chave — versão 1.2.4

A versão 1.2.4 integra o SDK Android Porcupine 4.0.2 para detectar a palavra integrada **JARVIS**. Em Ajustes → Voz e microfone, cole a AccessKey do Picovoice Console e salve as configurações; a chave é guardada no cofre nativo do Android quando esse plugin está disponível. A conta Picovoice disponibiliza uma chave gratuita, mas é necessário conferir as condições/limites atuais do serviço. Não use uma chave publicada em repositório público.

Depois, ative **Ativar palavra de ativação “Jarvis”**. Diga “Jarvis”, aguarde o bipe e então fale o pedido. O detector de palavra-chave processa o áudio localmente; a transcrição completa só começa após o gatilho. O detector não grava nem envia uma transcrição contínua do ambiente. A inicialização/validação da chave pode precisar de internet; a detecção local não depende de enviar o áudio para uma API de IA.

**Limites que ainda exigem teste real:** pronúncia brasileira de “Jarvis”, falsos acionamentos, consumo de bateria, coexistência com música/telefonia, comportamento após sair do app e limitações de segundo plano do fabricante. O serviço Android continua sujeito às políticas do sistema; não se deve prometer funcionamento garantido se o Android encerrar o processo. Não há APK compilado nem teste físico incluído nesta revisão de fonte.
